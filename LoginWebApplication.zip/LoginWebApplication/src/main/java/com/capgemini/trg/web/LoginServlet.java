package com.capgemini.trg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.trg.exception.UserException;
import com.capgemini.trg.service.IUserService;
import com.capgemini.trg.service.UserServiceImpl;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IUserService userService=new UserServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		if(username.length()==0) {
			throw new NullPointerException("Username is null");
		}
		String password=request.getParameter("password");
		if(password.length()==0) {
			throw new NullPointerException("Password is null");
		}	
		
		try {
			String status=null;
			
			if(isValidUser(username,password) ==true) {
				HttpSession session=request.getSession();
				session.setAttribute("username", username);
				//provide relative path
				/*request.
				getRequestDispatcher("views/user_menu.jsp").
				forward(request, response);*/
				
				//provide absolute path
				getServletContext().
				getRequestDispatcher("/views/user_menu.jsp").
				forward(request, response);
				
			}else {
				status="Invalid Credentials,"+username+","+password;
			}
			request.setAttribute("status",status );
			RequestDispatcher rd=
					request.getRequestDispatcher("views/status.jsp");
			rd.forward(request, response);
				
		}catch(Exception e) {
			response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE,e.getMessage()+"Enter Userid and Password");
		}
		
	}

	
	private boolean isValidUser(String username, String password) {
		try {
			return userService.isValidUser(username, password);
		} catch (UserException e) {
			return false;			
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
