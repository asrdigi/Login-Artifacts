package com.capgemini.trg.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.trg.entity.User;
import com.capgemini.trg.exception.UserException;
import com.capgemini.trg.service.IUserService;
import com.capgemini.trg.service.UserServiceImpl;


@WebServlet("/getuserdetails")
public class GetUserDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IUserService userService=
			 new UserServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			Integer userid=
					Integer.parseInt(request.getParameter("userid"));
			User user=
					userService.getUserDetails(userid);
			request.setAttribute("user", user);
			request.
			getRequestDispatcher("views/show_user_details.jsp").
			forward(request, response);
		}catch(UserException e) {
			request.setAttribute("status", e.getMessage());
			request.getRequestDispatcher("views/status.jsp").
			forward(request, response);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
